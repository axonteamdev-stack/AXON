# MeddioDoc API Documentation

**Base URL:** `http://localhost:8000/api/v1`

**Default Language Header:** `accept-language: ar` (or `en` for English)

---

## 🔐 Authentication Endpoints

### 1. Patient Signup

- **Method:** `POST`
- **URL:** `/auth/signup-patient`
- **Authentication:** None
- **Description:** Register a new patient account
- **Content-Type:** `multipart/form-data`

**Request Body:**

```json
{
  "fullName": "أحمد محمود",
  "email": "patient@example.com",
  "password": "Password123!",
  "passwordConfirm": "Password123!",
  "phoneNumber": "+201234567890",
  "gender": "male",
  "bloodType": "O+"
}
```

**Files:**

- `personalPhoto`: (image file)

**Response (201):**

```json
{
  "status": "success",
  "message": "Patient registration submitted successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "fullName": "أحمد محمود",
    "email": "patient@example.com",
    "phoneNumber": "+201234567890",
    "role": "patient",
    "isVerified": false,
    "personalPhoto": "Uploads/PersonalPhoto/patient-1712700000000.jpg",
    "medicalProfile": {
      "bloodType": "O+",
      "weight": 0
    }
  }
}
```

---

### 2. Doctor Signup

- **Method:** `POST`
- **URL:** `/auth/signup-doctor`
- **Authentication:** None
- **Description:** Register a new doctor account
- **Content-Type:** `multipart/form-data`

**Request Body:**

```json
{
  "fullName": "د. محمد علي",
  "email": "doctor@example.com",
  "password": "Password123!",
  "passwordConfirm": "Password123!",
  "phoneNumber": "+201234567890",
  "gender": "male",
  "specialization": "Cardiology",
  "yearsExperience": 10,
  "medicalLicenseNumber": "MED123456",
  "about": "متخصص في أمراض القلب والأوعية الدموية"
}
```

**Files:**

- `personalPhoto`: (image file)
- `licenseImage`: (image file - required for doctor)

**Response (201):**

```json
{
  "status": "success",
  "message": "Doctor registration submitted successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439012",
    "fullName": "د. محمد علي",
    "email": "doctor@example.com",
    "role": "doctor",
    "isVerified": false
  }
}
```

---

### 3. Login

- **Method:** `POST`
- **URL:** `/auth/login`
- **Authentication:** None
- **Description:** Login to existing account

**Request Body:**

```json
{
  "email": "patient@example.com",
  "password": "Password123!"
}
```

**Response (200):**

```json
{
  "status": "success",
  "message": "Logged in successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "fullName": "أحمد محمود",
    "email": "patient@example.com",
    "role": "patient",
    "isVerified": true
  }
}
```

---

### 4. Refresh Token

- **Method:** `POST`
- **URL:** `/auth/refresh-token`
- **Authentication:** Bearer Token or refreshToken Cookie
- **Description:** Get new access token using refresh token

**Response (200):**

```json
{
  "status": "success",
  "message": "Token refreshed successfully",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

### 5. Logout

- **Method:** `POST`
- **URL:** `/auth/logout`
- **Authentication:** Bearer Token (JWT)
- **Description:** Logout from current session

**Response (200):**

```json
{
  "status": "success",
  "message": "Logged out successfully"
}
```

---

### 6. Forgot Password

- **Method:** `POST`
- **URL:** `/auth/forgot-password`
- **Authentication:** None
- **Description:** Request password reset code

**Request Body:**

```json
{
  "email": "patient@example.com"
}
```

**Response (200):**

```json
{
  "status": "success",
  "message": "Verification code sent to email"
}
```

---

### 7. Reset Password

- **Method:** `PATCH`
- **URL:** `/auth/reset-password`
- **Authentication:** None
- **Description:** Reset password using verification code

**Request Body:**

```json
{
  "token": "123456",
  "password": "NewPassword123!",
  "passwordConfirm": "NewPassword123!"
}
```

**Response (200):**

```json
{
  "status": "success",
  "message": "Password changed successfully"
}
```

---

### 8. Update Profile (updateMe)

- **Method:** `PATCH`
- **URL:** `/auth/updateMe`
- **Authentication:** Bearer Token (JWT)
- **Description:** Update current user profile
- **Content-Type:** `multipart/form-data`

**Request Body:**

```json
{
  "fullName": "أحمد محمود محمد",
  "phoneNumber": "+201234567891",
  "gender": "male",
  "bloodType": "O+",
  "weight": 75
}
```

**Files:**

- `personalPhoto`: (image file - optional)

**Response (200):**

```json
{
  "status": "success",
  "message": "Data updated successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "fullName": "أحمد محمود محمد",
    "phoneNumber": "+201234567891"
  }
}
```

---

## 👥 User/Doctor Endpoints

### 1. Get All Doctors

- **Method:** `GET`
- **URL:** `/auth/all-doctors`
- **Authentication:** Bearer Token (JWT)
- **Description:** Get list of all verified doctors

**Response (200):**

```json
{
  "status": "success",
  "message": "All doctors data merged and fetched successfully",
  "data": {
    "results": 5,
    "doctors": [
      {
        "_id": "507f1f77bcf86cd799439012",
        "fullName": "د. محمد علي",
        "email": "doctor@example.com",
        "specialization": "Cardiology",
        "yearsExperience": 10,
        "price": 150,
        "personalPhoto": "Uploads/PersonalPhoto/doctor-1712700000001.jpg"
      }
    ]
  }
}
```

---

### 2. Get Doctor Details

- **Method:** `GET`
- **URL:** `/auth/doctor/:id`
- **Authentication:** Bearer Token (JWT)
- **Description:** Get detailed information about a specific doctor
- **URL Parameters:**
  - `id`: Doctor's ID (e.g., `507f1f77bcf86cd799439012`)

**Response (200):**

```json
{
  "status": "success",
  "message": "Doctor details fetched successfully",
  "data": {
    "doctor": {
      "_id": "507f1f77bcf86cd799439012",
      "fullName": "د. محمد علي",
      "email": "doctor@example.com",
      "gender": "male",
      "specialization": "Cardiology",
      "yearsExperience": 10,
      "about": "متخصص في أمراض القلب والأوعية الدموية",
      "price": 150
    }
  }
}
```

---

### 3. Search Doctors

- **Method:** `POST`
- **URL:** `/auth/search-doctors`
- **Authentication:** Bearer Token (JWT)
- **Description:** Search for doctors by keyword or specialization

**Request Body:**

```json
{
  "keyword": "محمد",
  "specialization": "Cardiology"
}
```

**Response (200):**

```json
{
  "status": "success",
  "message": "Search results are ready",
  "data": {
    "results": 2,
    "doctors": [
      {
        "_id": "507f1f77bcf86cd799439012",
        "fullName": "د. محمد علي",
        "specialization": "Cardiology",
        "price": 150,
        "personalPhoto": "Uploads/PersonalPhoto/doctor-1712700000001.jpg"
      }
    ]
  }
}
```

---

### 4. Follow/Unfollow Doctor

- **Method:** `PATCH`
- **URL:** `/auth/follow/:id`
- **Authentication:** Bearer Token (JWT)
- **Description:** Follow or unfollow a doctor
- **URL Parameters:**
  - `id`: Doctor's ID

**Response (200) - Follow:**

```json
{
  "status": "success",
  "message": "Followed successfully"
}
```

**Response (200) - Unfollow:**

```json
{
  "status": "success",
  "message": "Unfollowed successfully"
}
```

---

## 🔐 Admin Endpoints

*All admin endpoints require authentication and admin role*

### 1. Add User (Admin)

- **Method:** `POST`
- **URL:** `/admin/users`
- **Authentication:** Bearer Token (JWT) + Admin role required
- **Description:** Admin can add new users directly

**Request Body:**

```json
{
  "fullName": "علي محمد",
  "email": "newuser@example.com",
  "password": "Password123!",
  "phoneNumber": "+201234567890",
  "gender": "male",
  "role": "patient"
}
```

**Response (201):**

```json
{
  "status": "success",
  "message": "User added successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439013",
    "fullName": "علي محمد",
    "email": "newuser@example.com",
    "role": "patient",
    "isVerified": true
  }
}
```

---

### 2. Update User (Admin)

- **Method:** `PATCH`
- **URL:** `/admin/users/:id`
- **Authentication:** Bearer Token (JWT) + Admin role required
- **Description:** Admin can update any user
- **URL Parameters:**
  - `id`: User's ID

**Request Body:**

```json
{
  "fullName": "علي محمد أحمد",
  "phoneNumber": "+201234567891",
  "specialization": "Neurology",
  "yearsExperience": 8
}
```

**Response (200):**

```json
{
  "status": "success",
  "message": "Updated successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439013",
    "fullName": "علي محمد أحمد"
  }
}
```

---

### 3. Delete User (Admin)

- **Method:** `DELETE`
- **URL:** `/admin/users/:id`
- **Authentication:** Bearer Token (JWT) + Admin role required
- **Description:** Admin can delete any user
- **URL Parameters:**
  - `id`: User's ID

**Response (200):**

```json
{
  "status": "success",
  "message": "User and all data deleted successfully"
}
```

---

### 4. Activate Doctor (Admin)

- **Method:** `PATCH`
- **URL:** `/admin/activate-doctor/:id`
- **Authentication:** Bearer Token (JWT) + Admin role required
- **Description:** Admin can activate pending doctor accounts
- **URL Parameters:**
  - `id`: Doctor's ID

**Response (200):**

```json
{
  "status": "success",
  "message": "Doctor account activated successfully"
}
```

---

## 📄 Article Endpoints

### 1. Get All Articles

- **Method:** `GET`
- **URL:** `/articles`
- **Authentication:** None (Public)
- **Description:** Get all published articles

**Response (200):**

```json
{
  "status": "success",
  "message": "All articles fetched successfully",
  "data": [
    {
      "_id": "507f1f77bcf86cd799439014",
      "title": "أهمية الفحص الدوري",
      "content": "الفحص الدوري يساعد في اكتشاف الأمراض مبكراً...",
      "doctor": {
        "_id": "507f1f77bcf86cd799439012",
        "fullName": "د. محمد علي",
        "personalPhoto": "Uploads/PersonalPhoto/doctor-1712700000001.jpg"
      },
      "image": "Uploads/Articles/article-1712700000002.jpg",
      "createdAt": "2024-04-10T12:00:00.000Z"
    }
  ]
}
```

---

### 2. Create Article (Doctor Only)

- **Method:** `POST`
- **URL:** `/articles/create`
- **Authentication:** Bearer Token (JWT) + Doctor role required
- **Description:** Create a new article
- **Content-Type:** `multipart/form-data`

**Request Body:**

```json
{
  "title": "نصائح للعناية بصحة القلب",
  "content": "للحفاظ على صحة القلب يجب ممارسة الرياضة بانتظام وتناول طعام صحي..."
}
```

**Files:**

- `postImage`: (image file - optional)

**Response (201):**

```json
{
  "status": "success",
  "message": "Article published successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439015",
    "doctor": "507f1f77bcf86cd799439012",
    "title": "نصائح للعناية بصحة القلب",
    "content": "للحفاظ على صحة القلب يجب ممارسة الرياضة بانتظام وتناول طعام صحي...",
    "image": "Uploads/Articles/article-1712700000003.jpg",
    "createdAt": "2024-04-10T12:30:00.000Z"
  }
}
```

---

### 3. Get My Articles (Doctor Only)

- **Method:** `GET`
- **URL:** `/articles/my-articles`
- **Authentication:** Bearer Token (JWT) + Doctor role required
- **Description:** Get articles created by current doctor

**Response (200):**

```json
{
  "status": "success",
  "message": "Your articles fetched successfully",
  "data": [
    {
      "_id": "507f1f77bcf86cd799439015",
      "title": "نصائح للعناية بصحة القلب",
      "content": "للحفاظ على صحة القلب...",
      "createdAt": "2024-04-10T12:30:00.000Z"
    }
  ]
}
```

---

### 4. Get Following Feed Articles

- **Method:** `GET`
- **URL:** `/articles/following-feed`
- **Authentication:** Bearer Token (JWT)
- **Description:** Get articles from doctors you follow

**Response (200):**

```json
{
  "status": "success",
  "message": "Following feed articles fetched successfully",
  "data": [
    {
      "_id": "507f1f77bcf86cd799439014",
      "title": "أهمية الفحص الدوري",
      "doctor": {
        "_id": "507f1f77bcf86cd799439012",
        "fullName": "د. محمد علي"
      }
    }
  ]
}
```

---

### 5. Get Article Details

- **Method:** `GET`
- **URL:** `/articles/getArticle/:id`
- **Authentication:** Bearer Token (JWT) + Doctor role required
- **Description:** Get specific article details
- **URL Parameters:**
  - `id`: Article's ID

**Response (200):**

```json
{
  "status": "success",
  "message": "Article fetched successfully",
  "data": {
    "article": {
      "_id": "507f1f77bcf86cd799439014",
      "title": "أهمية الفحص الدوري",
      "content": "الفحص الدوري يساعد في اكتشاف الأمراض مبكراً...",
      "doctor": "507f1f77bcf86cd799439012",
      "image": "Uploads/Articles/article-1712700000002.jpg"
    }
  }
}
```

---

## 💊 Medication Endpoints

*All medication endpoints require authentication and patient role*

### 1. Get My Medications

- **Method:** `GET`
- **URL:** `/medications`
- **Authentication:** Bearer Token (JWT) + Patient role required
- **Description:** Get all medications for current patient

**Response (200):**

```json
{
  "status": "success",
  "message": "Medications list fetched successfully",
  "data": [
    {
      "_id": "507f1f77bcf86cd799439016",
      "medicineName": "Aspirin",
      "frequency": 2,
      "intakeTime": ["08:00", "20:00"],
      "startDate": "2024-04-10",
      "endDate": "2024-05-10",
      "duration": "30 days",
      "isActive": true
    }
  ]
}
```

---

### 2. Add Medication

- **Method:** `POST`
- **URL:** `/medications`
- **Authentication:** Bearer Token (JWT) + Patient role required
- **Description:** Add new medication to patient's list

**Request Body:**

```json
{
  "medicineName": "Aspirin",
  "frequency": 2,
  "intakeTime": "08:00",
  "startDate": "2024-04-10",
  "endDate": "2024-05-10"
}
```

**Response (201):**

```json
{
  "status": "success",
  "message": "Medication added successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439016",
    "medicineName": "Aspirin",
    "frequency": 2,
    "intakeTime": ["08:00", "20:00"],
    "startDate": "2024-04-10",
    "endDate": "2024-05-10",
    "duration": "30 days",
    "isActive": true,
    "patientId": "507f1f77bcf86cd799439011"
  }
}
```

---

### 3. Update Medication

- **Method:** `PATCH`
- **URL:** `/medications/:id`
- **Authentication:** Bearer Token (JWT) + Patient role required
- **Description:** Update existing medication
- **URL Parameters:**
  - `id`: Medication's ID

**Request Body:**

```json
{
  "frequency": 3,
  "intakeTime": "08:00",
  "endDate": "2024-05-15"
}
```

**Response (200):**

```json
{
  "status": "success",
  "message": "Medication updated successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439016",
    "medicineName": "Aspirin",
    "frequency": 3,
    "endDate": "2024-05-15"
  }
}
```

---

### 4. Get Single Medication

- **Method:** `GET`
- **URL:** `/medications/:id`
- **Authentication:** Bearer Token (JWT) + Patient role required
- **Description:** Get specific medication details
- **URL Parameters:**
  - `id`: Medication's ID

**Response (200):**

```json
{
  "status": "success",
  "message": "Medication details fetched successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439016",
    "medicineName": "Aspirin",
    "frequency": 2,
    "intakeTime": ["08:00", "20:00"],
    "startDate": "2024-04-10",
    "endDate": "2024-05-10",
    "duration": "30 days",
    "isActive": true
  }
}
```

---

### 5. Delete Medication

- **Method:** `DELETE`
- **URL:** `/medications/:id`
- **Authentication:** Bearer Token (JWT) + Patient role required
- **Description:** Delete medication from patient's list
- **URL Parameters:**
  - `id`: Medication's ID

**Response (200):**

```json
{
  "status": "success",
  "message": "Medication deleted successfully"
}
```

---

## 🔑 Authentication Headers

For all protected endpoints, include:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

Or include the JWT token in cookies:

```
Cookie: jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## 🌍 Language Support

All responses support Arabic (ar) and English (en).

**Set language in request header:**

```
accept-language: ar
```

or

```
accept-language: en
```

---

## ❌ Common Error Responses

### 404 - Not Found

```json
{
  "status": "fail",
  "message": "The requested path was not found"
}
```

### 401 - Unauthorized

```json
{
  "status": "fail",
  "message": "You are not logged in, please log in to access"
}
```

### 403 - Forbidden

```json
{
  "status": "fail",
  "message": "You do not have permission to access this feature"
}
```

### 400 - Bad Request

```json
{
  "status": "fail",
  "message": "Please enter email and password"
}
```

### 500 - Server Error

```json
{
  "status": "error",
  "message": "Internal server error"
}
```

---

## 📋 Sample Postman Collection URLs

Copy-paste these URLs directly into Postman:

### Authentication

- POST: `{{baseUrl}}/auth/signup-patient`
- POST: `{{baseUrl}}/auth/signup-doctor`
- POST: `{{baseUrl}}/auth/login`
- POST: `{{baseUrl}}/auth/logout`
- POST: `{{baseUrl}}/auth/refresh-token`
- POST: `{{baseUrl}}/auth/forgot-password`
- PATCH: `{{baseUrl}}/auth/reset-password`
- PATCH: `{{baseUrl}}/auth/updateMe`

### Users/Doctors

- GET: `{{baseUrl}}/auth/all-doctors`
- GET: `{{baseUrl}}/auth/doctor/507f1f77bcf86cd799439012`
- POST: `{{baseUrl}}/auth/search-doctors`
- PATCH: `{{baseUrl}}/auth/follow/507f1f77bcf86cd799439012`

### Admin (Admin role required)

- POST: `{{baseUrl}}/admin/users`
- PATCH: `{{baseUrl}}/admin/users/507f1f77bcf86cd799439011`
- DELETE: `{{baseUrl}}/admin/users/507f1f77bcf86cd799439011`
- PATCH: `{{baseUrl}}/admin/activate-doctor/507f1f77bcf86cd799439012`

### Articles

- GET: `{{baseUrl}}/articles`
- POST: `{{baseUrl}}/articles/create`
- GET: `{{baseUrl}}/articles/my-articles`
- GET: `{{baseUrl}}/articles/following-feed`
- GET: `{{baseUrl}}/articles/getArticle/507f1f77bcf86cd799439014`

### Medications

- GET: `{{baseUrl}}/medications`
- POST: `{{baseUrl}}/medications`
- PATCH: `{{baseUrl}}/medications/507f1f77bcf86cd799439016`
- GET: `{{baseUrl}}/medications/507f1f77bcf86cd799439016`
- DELETE: `{{baseUrl}}/medications/507f1f77bcf86cd799439016`

---

## 🔄 Environment Variables for Postman

Create a Postman environment with these variables:

```json
{
  "baseUrl": "http://localhost:8000/api/v1",
  "token": "your_jwt_token_here",
  "doctorId": "507f1f77bcf86cd799439012",
  "patientId": "507f1f77bcf86cd799439011",
  "medicationId": "507f1f77bcf86cd799439016",
  "articleId": "507f1f77bcf86cd799439014"
}
```

Then use `{{baseUrl}}`, `{{token}}`, etc. in your requests.

---

**Last Updated:** April 10, 2024
**Version:** 1.0
**Status:** Production Ready ✅
