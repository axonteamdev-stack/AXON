# Error Handling & Multilingual Response Implementation

## Overview

The entire AXON backend project has been refactored to use a centralized, bilingual (Arabic/English) error handling and response system using:

- **CustomErrorHandler** (`Src/Error/CustomErrorHandeler.js`) - Base error class
- **AppError** (`Src/Utils/AppError.js`) - Enhanced error class extending CustomErrorHandler
- **Translations** (`Src/Utils/Translations.js`) - Centralized message repository
- **sendResponse** - Unified success response handler

## Architecture

### 1. Custom Error Handler (`CustomErrorHandeler.js`)

- Base class extending native Error
- Provides statusCode and status properties
- Captures stack traces in development mode

### 2. AppError (`AppError.js`)

- Extends CustomAPIError
- Accepts three input formats:
  - Translation key (string): `new AppError('USER_NOT_FOUND', 404)`
  - Bilingual object: `new AppError({ ar: '...', en: '...' }, 404)`
  - Plain string: `new AppError('Error message', 404)`
- Automatically resolves keys to translations via `getMessage()`
- Stores multilingual messages for global error handler

### 3. Translation System (`Translations.js`)

Centralized message repository with 80+ message keys covering:

- **User Management**: USER_NOT_FOUND, USER_ADDED_SUCCESS, USER_UPDATED_SUCCESS, USER_DELETED_SUCCESS
- **Doctor Operations**: DOCTOR_NOT_FOUND, DOCTOR_NOT_FOUND_GENERAL, DOCTOR_ACTIVATED_SUCCESS, DOCTOR_DETAILS_FETCHED, DOCTORS_FETCHED_SUCCESS
- **Follow/Unfollow**: CANNOT_FOLLOW_YOURSELF, FOLLOWED_SUCCESS, UNFOLLOWED_SUCCESS
- **Authentication**: EMAIL_ALREADY_REGISTERED, INVALID_CREDENTIALS, ACCOUNT_PENDING_APPROVAL, SESSION_EXPIRED, INVALID_OR_EXPIRED_CODE
- **Articles**: ARTICLE_NOT_FOUND, ARTICLE_PUBLISHED_SUCCESS, ALL_ARTICLES_FETCHED_SUCCESS, ARTICLE_FETCHED_SUCCESS
- **Medications**: MEDICATION_NOT_FOUND, MEDICATION_ADDED_SUCCESS, MEDICATION_UPDATED_SUCCESS, MEDICATION_DELETED_SUCCESS
- **Middleware**: NOT_LOGGED_IN, TOKEN_OWNER_NOT_FOUND, INVALID_OR_EXPIRED_TOKEN, NO_PERMISSION
- **General**: PATH_NOT_FOUND, SERVER_RUNNING, EMAIL_SEND_FAILED, PASSWORD_RESET_SUCCESS

### 4. Success Response Handler (`sendResponse`)

```javascript
sendResponse(res, statusCode, messageKey, data = null)
```

- Automatically detects user language from `req.lang` (set by `setLanguage` middleware)
- Supports both translation keys and bilingual objects
- Returns consistent JSON structure: `{ status: 'success', message: '...', data: {...} }`

## Implementation Details

### Error Flow

1. Controller throws error: `new AppError('DOCTOR_NOT_FOUND', 404)`
2. Error caught by `catchAsync` wrapper
3. Passed to global error handler
4. Handler extracts language from `req.lang`
5. Resolves message based on language preference
6. Returns localized JSON response

### Success Flow

1. Controller calls: `sendResponse(res, 200, 'USER_ADDED_SUCCESS', userData)`
2. Handler detects language from `req.lang`
3. Resolves message key to appropriate language
4. Returns consistent success response with message and data

## Language Detection

- Language set by `setLanguage` middleware in `Src/Middlewares/langMiddleware.js`
- Reads from request header: `accept-language` header
- Defaults to Arabic ('ar') if not specified
- Supported languages: 'ar', 'en'

## Files Updated

### Controllers (5 files)

1. **AdminController.js** - All user management operations
2. **AuthController.js** - Registration, login, password reset, logout
3. **UserController.js** - Doctor listing, search, follow operations
4. **ArticleController.js** - Article CRUD operations
5. **MedicationController.js** - Medication CRUD operations

### Middlewares (1 file)

1. **AuthMiddleware.js** - Protected route errors

### Utils (1 file)

1. **Translations.js** - Comprehensive message repository

### Global (1 file)

1. **app.js** - 404 handler, global error handler

## Key Features

✅ **Bilingual Support**: Every error and success message in Arabic and English
✅ **Centralized Translations**: All messages in single `Translations.js` file
✅ **Translation Keys**: Uses meaningful keys for maintainability
✅ **Automatic Language Detection**: Based on user's browser language preference
✅ **Consistent Response Format**: All success/error responses follow same structure
✅ **Backward Compatible**: Still supports bilingual object format for dynamic messages
✅ **Development Support**: Stack traces and error details in development mode
✅ **Zero Hardcoding**: No hardcoded strings in controllers/middlewares

## Usage Examples

### Throwing Errors

```javascript
// Using translation key
if (!user) return next(new AppError('USER_NOT_FOUND', 404));

// Using bilingual object (for dynamic messages)
const error = new AppError({
  ar: `العنوان المطلوب ${url} غير موجود!`,
  en: `The requested path ${url} was not found!`
}, 404);
```

### Sending Success Responses

```javascript
// Using translation key
sendResponse(res, 201, 'USER_ADDED_SUCCESS', newUser);

// With data
sendResponse(res, 200, 'DOCTORS_FETCHED_SUCCESS', { 
  results: doctors.length, 
  doctors: doctors 
});

// Without data
sendResponse(res, 200, 'LOGOUT_SUCCESS');
```

## Testing

All files have been validated for syntax correctness:

- ✅ Controllers: AdminController, AuthController, UserController, ArticleController, MedicationController
- ✅ Middlewares: AuthMiddleware, ValidateMiddleware
- ✅ Utils: AppError, Translations
- ✅ Main: app.js, server.js

## Future Enhancements

- Add validation error translations
- Create error logging system with language support
- Add email templates with translations
- Implement rate-limit error messages in translations
